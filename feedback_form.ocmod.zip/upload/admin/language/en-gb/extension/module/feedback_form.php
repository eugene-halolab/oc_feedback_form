<?php
// Heading
$_['heading_title']    = 'Feedback form';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified feedback form module!';
$_['text_edit']        = 'Edit feedback form Module';

$_['entry_status']     = 'Status';

$_['error_permission'] = 'Warning: You do not have permission to modify Feedback form module!';
