<?php
// Text
$_['text_name']     = 'Your Name:';
$_['text_email']    = 'Your Email:';
$_['text_phone']    = 'Your Phone:';
$_['text_submit']   = 'Submit';

$_['text_success'] = 'Your feedback has been successfully submitted!';